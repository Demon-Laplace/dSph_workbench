import argparse
import csv
import re
import sys
from pathlib import Path


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
FIXTURE_CASE_ROOT = WORKSPACE_ROOT / "fixtures_realistic" / "mock_server"

MODEL_SPEC_TOKEN_PATTERN = re.compile(r"^\d+(?:-\d+)?$")
IC_INI_PATTERN_TEMPLATE = r"^IC_snapshot(?P<snapshot>\d+)_{prefix}(?P<ic_model>\d+)\.ini$"


def parse_args():
    parser = argparse.ArgumentParser(
        description=(
            "Inspect Fornax production cases and report which initial condition "
            "each model uses."
        )
    )
    parser.add_argument(
        "model_specs",
        nargs="+",
        help=(
            'Model selectors such as "1035", "1035-1087", or "1035,1087,2001-2027". '
            "Ranges are inclusive."
        ),
    )
    parser.add_argument(
        "--case-root",
        type=Path,
        help=(
            "Root directory containing Fornax model folders. "
            "Default: auto-detect current working directory first, then local fixture path."
        ),
    )
    parser.add_argument(
        "--prefix",
        default="Fornax",
        help='Model directory and IC prefix. Default: "Fornax".',
    )
    parser.add_argument(
        "--format",
        choices=("pretty", "csv", "tsv"),
        default="pretty",
        help="Output format. Default: pretty.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        help=(
            "Optional output file. If provided, parent directories are created. "
            "Write outside fixtures, e.g. under sandbox_runs/."
        ),
    )
    return parser.parse_args()


def expand_model_specs(specs):
    model_ids = set()
    for spec in specs:
        for token in spec.split(","):
            token = token.strip()
            if not token:
                continue
            if not MODEL_SPEC_TOKEN_PATTERN.fullmatch(token):
                raise ValueError(
                    f'Invalid model selector "{token}". Use forms like "1035" or "2001-2027".'
                )
            if "-" in token:
                start_text, end_text = token.split("-", maxsplit=1)
                start = int(start_text)
                end = int(end_text)
                if start > end:
                    raise ValueError(
                        f'Invalid model selector "{token}": range start must be <= end.'
                    )
                model_ids.update(range(start, end + 1))
            else:
                model_ids.add(int(token))
    if not model_ids:
        raise ValueError("No model ids were provided.")
    return sorted(model_ids)


def inspect_model(case_root, prefix, model_id):
    case_dir = case_root / f"{prefix}{model_id}"
    row = {
        "model": f"{prefix}{model_id}",
        "model_id": str(model_id),
        "case_dir": str(case_dir),
        "ic_snapshot": "",
        "ic_model": "",
        "ic_file": "",
        "status": "",
        "message": "",
    }

    if not case_dir.exists():
        row["status"] = "case_missing"
        row["message"] = "model directory not found"
        return row

    if not case_dir.is_dir():
        row["status"] = "case_invalid"
        row["message"] = "model path exists but is not a directory"
        return row

    ic_pattern = re.compile(IC_INI_PATTERN_TEMPLATE.format(prefix=re.escape(prefix)))
    matched_files = sorted(
        path
        for path in case_dir.iterdir()
        if path.is_file() and ic_pattern.fullmatch(path.name)
    )

    if not matched_files:
        row["status"] = "ic_ini_missing"
        row["message"] = "no IC_snapshot ini file found"
        return row

    if len(matched_files) > 1:
        matched_names = [path.name for path in matched_files]
        row["status"] = "ic_ini_ambiguous"
        row["message"] = (
            f"found {len(matched_files)} IC_snapshot ini files: "
            + ", ".join(matched_names)
        )
        row["ic_file"] = ";".join(matched_names)
        return row

    ic_file = matched_files[0]
    match = ic_pattern.fullmatch(ic_file.name)
    if match is None:
        row["status"] = "ic_ini_parse_error"
        row["message"] = "matched file could not be parsed"
        row["ic_file"] = ic_file.name
        return row

    row["ic_snapshot"] = match.group("snapshot")
    row["ic_model"] = f"{prefix}{match.group('ic_model')}"
    row["ic_file"] = ic_file.name
    row["status"] = "ok"
    row["message"] = f"{row['model']} uses {row['ic_model']} from snapshot {row['ic_snapshot']}"
    return row


def has_model_dirs(case_root, prefix):
    if not case_root.exists() or not case_root.is_dir():
        return False
    return any(
        path.is_dir() and path.name.startswith(prefix)
        for path in case_root.iterdir()
    )


def resolve_case_root(case_root_arg, prefix):
    if case_root_arg is not None:
        return case_root_arg.resolve()

    cwd_root = Path.cwd().resolve()
    if has_model_dirs(cwd_root, prefix):
        return cwd_root

    if has_model_dirs(FIXTURE_CASE_ROOT, prefix):
        return FIXTURE_CASE_ROOT.resolve()

    return cwd_root


def collect_rows(case_root, prefix, model_ids):
    return [inspect_model(case_root=case_root, prefix=prefix, model_id=model_id) for model_id in model_ids]


def render_pretty(rows):
    headers = ["model", "ic_model", "ic_snapshot", "ic_file", "status"]
    widths = {header: len(header) for header in headers}
    for row in rows:
        for header in headers:
            widths[header] = max(widths[header], len(row[header]))

    lines = [
        "  ".join(header.ljust(widths[header]) for header in headers),
        "  ".join("-" * widths[header] for header in headers),
    ]
    for row in rows:
        lines.append(
            "  ".join(row[header].ljust(widths[header]) for header in headers)
        )

    notes = [f"{row['model']}: {row['message']}" for row in rows if row["status"] != "ok"]
    if notes:
        lines.append("")
        lines.append("Notes:")
        lines.extend(notes)
    return "\n".join(lines)


def write_delimited(rows, delimiter, output_stream):
    fieldnames = ["model", "model_id", "case_dir", "ic_snapshot", "ic_model", "ic_file", "status", "message"]
    writer = csv.DictWriter(output_stream, fieldnames=fieldnames, delimiter=delimiter)
    writer.writeheader()
    writer.writerows(rows)


def ensure_output_parent(output_path):
    output_path.parent.mkdir(parents=True, exist_ok=True)


def main():
    args = parse_args()
    case_root = resolve_case_root(args.case_root, args.prefix)

    try:
        model_ids = expand_model_specs(args.model_specs)
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2

    rows = collect_rows(case_root=case_root, prefix=args.prefix, model_ids=model_ids)

    if args.output is not None:
        output_path = args.output.resolve()
        ensure_output_parent(output_path)
        with output_path.open("w", encoding="utf-8", newline="") as handle:
            if args.format == "pretty":
                handle.write(render_pretty(rows))
                handle.write("\n")
            elif args.format == "csv":
                write_delimited(rows, delimiter=",", output_stream=handle)
            else:
                write_delimited(rows, delimiter="\t", output_stream=handle)
    else:
        if args.format == "pretty":
            print(render_pretty(rows))
        elif args.format == "csv":
            write_delimited(rows, delimiter=",", output_stream=sys.stdout)
        else:
            write_delimited(rows, delimiter="\t", output_stream=sys.stdout)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
