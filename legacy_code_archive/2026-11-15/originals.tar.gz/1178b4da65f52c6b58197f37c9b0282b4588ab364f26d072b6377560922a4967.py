import gc
import os
import ctypes
import resource
import shutil
import subprocess
import sys
import time

os.environ.setdefault("MPLCONFIGDIR", "/tmp/mplconfig-dsph")
os.makedirs(os.environ["MPLCONFIGDIR"], exist_ok=True)

import numpy as np
import pandas as pd
from astropy.coordinates import CartesianRepresentation, CartesianDifferential, SkyCoord
# from scipy.interpolate import UnivariateSpline
import astropy.units as u
import matplotlib.pyplot as plt
from matplotlib import gridspec
import warnings

from basefunc import Analysis, DataProcessor, GalaxySimulation
from mpl_toolkits.axes_grid1 import make_axes_locatable
import argparse
# from multiprocessing import Pool
from multiprocessing import get_context
from snapshot_context import prepare_snapshot_context

from matplotlib.patches import Ellipse
from variable import (
    cd_threshold,
    core_radius_dict,
    cube_path,
    d_today,
    err_sigma,
    fndens,
    folder_path,
    obs_plot_mass_to_light_ratio,
    obs_surface_brightness_factor_base,
    output_folder,
    r_pc,
    sim_plot_mass_to_light_ratio,
    sigma,
    xylabel_size,
)

warnings.filterwarnings("ignore")
plt.switch_backend('Agg')

PLOT_CONTEXT = None

try:
    LIBC = ctypes.CDLL("libc.so.6")
except OSError:
    LIBC = None

try:
    from threadpoolctl import threadpool_limits
except ImportError:
    threadpool_limits = None

try:
    from tqdm.auto import tqdm
except ImportError:
    tqdm = None

THREADPOOL_CONTROLLER = None


def render_video_from_frames(output_dir, dwarf_name, model_num, start_numsp, frame_count):
    if frame_count <= 0:
        print("[PlotFigVideo] Skip video generation: no frames requested")
        return None

    ffmpeg_path = shutil.which("ffmpeg")
    if ffmpeg_path is None:
        print("[PlotFigVideo] Skip video generation: ffmpeg not found in PATH")
        return None

    output_dir = os.path.abspath(output_dir)
    output_name = f"{dwarf_name}{model_num}_v2.mp4"
    output_path = os.path.join(output_dir, output_name)
    cmd = [
        ffmpeg_path,
        "-start_number",
        str(start_numsp),
        "-i",
        "check_nature_%03d.png",
        "-vf",
        "scale=3416:1886",
        "-frames:v",
        str(frame_count),
        "-crf",
        "18",
        "-pix_fmt",
        "yuv420p",
        "-y",
        output_name,
    ]

    try:
        subprocess.run(
            cmd,
            cwd=output_dir,
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.STDOUT,
        )
    except subprocess.CalledProcessError as exc:
        print(f"[PlotFigVideo] ffmpeg failed with exit code {exc.returncode}")
        return None

    print(f"[PlotFigVideo] Saved video: {output_path}")
    return output_path


def build_consecutive_blocks(items, block_size):
    if block_size <= 0:
        raise ValueError("block_size must be positive")
    return [items[i:i + block_size] for i in range(0, len(items), block_size)]


class ProgressReporter:
    def __init__(self, total, desc, enabled=True, unit='snap', mininterval=0.5):
        self.total = total
        self.desc = desc
        self.enabled = enabled and total > 0
        self.unit = unit
        self.mininterval = mininterval
        self.count = 0
        self._last_print = 0.0
        self._use_tqdm = self.enabled and tqdm is not None and sys.stdout.isatty()
        self._progress = None
        if self._use_tqdm:
            self._progress = tqdm(
                total=total,
                desc=desc,
                unit=unit,
                dynamic_ncols=True,
                mininterval=mininterval,
                file=sys.stdout,
            )
        elif self.enabled:
            print(f"[{self.desc}Progress] 0/{self.total} {self.unit}", flush=True)

    def update(self, n=1):
        if not self.enabled:
            return
        self.count += n
        if self._progress is not None:
            self._progress.update(n)
            return

        now = time.perf_counter()
        if self.count >= self.total or now - self._last_print >= self.mininterval:
            print(f"[{self.desc}Progress] {self.count}/{self.total} {self.unit}", flush=True)
            self._last_print = now

    def close(self):
        if self._progress is not None:
            self._progress.close()


def release_process_memory():
    gc.collect()
    if LIBC is not None:
        try:
            LIBC.malloc_trim(0)
        except Exception:
            pass


def get_rss_mb():
    try:
        with open("/proc/self/statm", "r") as fh:
            rss_pages = int(fh.readline().split()[1])
        page_size = os.sysconf("SC_PAGE_SIZE")
        return rss_pages * page_size / (1024.0 * 1024.0)
    except Exception:
        return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0


def init_worker(worker_threads):
    global THREADPOOL_CONTROLLER
    if threadpool_limits is not None and worker_threads is not None and worker_threads > 0:
        THREADPOOL_CONTROLLER = threadpool_limits(limits=worker_threads)


def build_plot_context():
    modelname, dwarf_name, num = DataProcessor.parse_model_name()
    inifile = DataProcessor.resolve_dwarf_ini_path(dwarf_name)
    print(f"[PlotFig] Using initial INI file: {inifile}")
    dw_particles = GalaxySimulation.get_dw_num(inifile)
    elinfo_path = f'./elinfo_{modelname}.csv'

    core_radius = core_radius_dict.get(dwarf_name, None)
    if core_radius is None:
        raise ValueError(f"please input '{dwarf_name}''s radius")

    dw_elinfo = DataProcessor.read_csv_with_comments(elinfo_path, dtype=DataProcessor.ELINFO_DTYPE_MAP)
    elinfo_by_numsp = dw_elinfo.set_index('numsp', drop=False)

    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
        print(f"Created output folder: {output_folder}")

    ini_x, ini_y, ini_z, ini_vx, ini_vy, ini_vz, fd_value = DataProcessor.get_ini_data(elinfo_path=elinfo_path)
    fd_factor_raw = fd_value / 8.3
    if fd_factor_raw >= 0.90:
        fd_factor_str = f"{round(fd_factor_raw):.0f}"
    else:
        fd_factor_str = f"{fd_factor_raw:.1f}"

    sfh_dw = pd.read_csv(f'../SFH_{dwarf_name}.csv')
    dprof = pd.read_csv(fndens)
    # factor = obs_surface_brightness_factor_base / obs_plot_mass_to_light_ratio
    factor = obs_surface_brightness_factor_base
    i_obs = dprof['density'] * factor
    i_obs_err = dprof['density_error'] * factor
    mag_obs = -2.5 * np.log10(i_obs)
    mag_obs_err = 1.0857 * (i_obs_err / i_obs)

    gas_loss_rate = Analysis.calculate_gas_loss_rate(dw_elinfo['age'].to_numpy(), dw_elinfo['coldgas_half_mass'].to_numpy())
    distance_series = dw_elinfo['distance_gal'] if 'distance_gal' in dw_elinfo.columns else dw_elinfo['distance']
    sigma_mw = np.where(
        dw_elinfo.sigma >= dw_elinfo.tsigma,
        np.sqrt(dw_elinfo.sigma**2 - dw_elinfo.tsigma**2),
        -np.sqrt(dw_elinfo.tsigma**2 - dw_elinfo.sigma**2),
    )
    sigma_mw_theoretical = Analysis.compute_sigma_mw(
        dw_elinfo['mw_mass_r'].to_numpy(),
        distance_series.to_numpy(),
        dw_elinfo['rhalf'].to_numpy(),
    )
    index_peri = distance_series.idxmin()
    d_peri = distance_series.loc[index_peri]
    t_peri = dw_elinfo.loc[index_peri, 'age']

    Tage = dw_elinfo.loc[
        distance_series.loc[:index_peri]
        .sub(d_today)
        .abs()
        .idxmin(),
        'age'
    ]
    dw_sfrmass = Analysis.GetSFH_sim(folder_path=folder_path, Tage=Tage)
    lookback_sim, sfr_sim, lookback_obs, sfr_obs = _compute_sfr_series(sfh_dw, dw_sfrmass, t_peri)

    return {
        'modelname': modelname,
        'dwarf_name': dwarf_name,
        'num': num,
        'inifile': inifile,
        'dw_particles': dw_particles,
        'elinfo_path': elinfo_path,
        'core_radius': core_radius,
        'dw_elinfo': dw_elinfo,
        'elinfo_by_numsp': elinfo_by_numsp,
        'ini_x': ini_x,
        'ini_y': ini_y,
        'ini_z': ini_z,
        'ini_vx': ini_vx,
        'ini_vy': ini_vy,
        'ini_vz': ini_vz,
        'fd_value': fd_value,
        'fd_factor_str': fd_factor_str,
        'sfh_dw': sfh_dw,
        'dprof': dprof,
        'mag_obs': mag_obs,
        'mag_obs_err': mag_obs_err,
        'gas_loss_rate': gas_loss_rate,
        'distance_series': distance_series,
        'sigma_mw': sigma_mw,
        'sigma_mw_theoretical': sigma_mw_theoretical,
        'd_peri': d_peri,
        't_peri': t_peri,
        'Tage': Tage,
        'dw_sfrmass': dw_sfrmass,
        'lookback_sim': lookback_sim,
        'sfr_sim': sfr_sim,
        'lookback_obs': lookback_obs,
        'sfr_obs': sfr_obs,
        'output_folder': output_folder,
    }


def get_plot_context():
    global PLOT_CONTEXT
    if PLOT_CONTEXT is None:
        PLOT_CONTEXT = build_plot_context()
    return PLOT_CONTEXT


def safe_plot(numsp, show_mem=False, profile=False, profile_memory=False, verbose=False):
    try:
        return plot(
            numsp,
            show_mem=show_mem,
            profile=profile,
            profile_memory=profile_memory,
            verbose=verbose,
        )
    except Exception as e:
        print(f"Error in numsp={numsp}: {e}")
        raise


def _style_axis(ax, xlabel, ylabel, xlim=None, ylim=None, invert_x=False):
    ax.set_xlabel(xlabel, fontsize=xylabel_size)
    ax.set_ylabel(ylabel, fontsize=xylabel_size)
    if xlim is not None:
        ax.set_xlim(*xlim)
    if ylim is not None:
        ax.set_ylim(*ylim)
    if invert_x:
        ax.invert_xaxis()
    ax.minorticks_on()
    ax.tick_params(axis='both', which='both', direction='in', top=True, right=True, labelsize=15)
    ax.grid(True)


def _append_colorbar(fig, ax, mappable, label):
    divider = make_axes_locatable(ax)
    cax = divider.append_axes("right", size="4%", pad=0.05)
    cbar = fig.colorbar(mappable, cax=cax)
    cbar.set_label(label, fontsize=14)
    cax.tick_params(axis='both', which='both', direction='in')
    cax.minorticks_on()
    return cbar


def _plot_gas_sky_panel(ax, cold_gas_x_kpc, cold_gas_y_kpc, hot_gas_x_kpc, hot_gas_y_kpc):
    ax.scatter(20, 20, s=18, color='aquamarine', label='HI Gas')
    ax.scatter(20, 20, s=18, color='orange', label='HII Gas')
    ax.scatter(cold_gas_x_kpc, cold_gas_y_kpc, s=4, color='aquamarine')
    ax.scatter(hot_gas_x_kpc, hot_gas_y_kpc, s=5, color='orange')
    _style_axis(ax, 'RA (kpc)', 'DEC (kpc)', xlim=(-5, 5), ylim=(-5, 5), invert_x=True)
    ax.legend(loc='upper left', fontsize=10)


def _plot_stellar_sky_panel(
    fig,
    ax,
    img,
    extent,
    cold_gas_center_ra,
    cold_gas_center_dec,
    x_contour,
    y_contour,
    cd_smooth,
    cd_threshold_str,
    mean_pmra,
    mean_pmdec,
    r_half_deg,
    eps,
    pa,
):
    arrow_length = 1.5
    norm = np.hypot(mean_pmra, mean_pmdec)
    dx_scaled = 0.0 if norm == 0 else mean_pmra / norm * arrow_length
    dy_scaled = 0.0 if norm == 0 else mean_pmdec / norm * arrow_length

    ax.arrow(
        0,
        0,
        dx_scaled,
        dy_scaled,
        head_width=0.1,
        head_length=0.1,
        fc='black',
        ec='black',
        alpha=0.7,
        lw=2,
    )

    im = ax.imshow(img.T, origin='lower', extent=extent, cmap='bone_r', vmin=22, vmax=34)
    ax.scatter(cold_gas_center_ra, cold_gas_center_dec, s=50, marker='x', color='red', label='HI Center')

    levels = np.linspace(cd_threshold, cd_smooth.max(), 5)
    contour_set = ax.contour(x_contour, y_contour, cd_smooth.T, levels=levels, colors='teal')
    contour_set.collections[0].set_label(f'$N_{{HI}} > {cd_threshold_str} atoms/cm^2$')

    _style_axis(ax, 'RA (deg)', 'DEC (deg)', xlim=(-2, 2), ylim=(-2, 2), invert_x=True)
    ax.legend(loc='lower right', fontsize=10)

    a = 4 * r_half_deg
    b = a * (1 - eps)
    ellipse = Ellipse(
        xy=(0, 0),
        width=2 * a,
        height=2 * b,
        angle=np.degrees(pa),
        edgecolor='dimgray',
        facecolor='none',
        lw=2,
        zorder=10,
    )
    ax.add_patch(ellipse)
    _append_colorbar(fig, ax, im, r'$\mu_V$ (mag arcsec$^{-2}$)')


def _plot_vlos_panel(fig, ax, vf, extent_vf):
    sc = ax.imshow(vf.T, origin='lower', extent=extent_vf, cmap='coolwarm', vmin=-12, vmax=12)
    _style_axis(ax, 'RA (kpc)', 'DEC (kpc)', xlim=(-5, 5), ylim=(-5, 5), invert_x=True)
    _append_colorbar(fig, ax, sc, r'<vlos> (km/s)')


def _plot_scene_panel(ax, cold_gas_y, cold_gas_z, hot_gas_y, hot_gas_z, star_y, star_z, cy, cz):
    arrow_length = 7
    total_distance = np.hypot(cy, cz)
    if total_distance > 0:
        normalized_cz = (-cy / total_distance) * arrow_length
        normalized_cy = (-cz / total_distance) * arrow_length
    else:
        normalized_cz = 0
        normalized_cy = 0

    ax.arrow(
        0,
        0,
        normalized_cz,
        normalized_cy,
        head_width=1.2,
        head_length=1.2,
        fc='black',
        ec='black',
        zorder=6,
    )
    ax.scatter(cold_gas_y - cy, cold_gas_z - cz, c='aquamarine', s=4, lw=0)
    ax.scatter(hot_gas_y - cy, hot_gas_z - cz, c='orange', s=2, lw=0)
    ax.scatter(star_y - cy, star_z - cz, c='gray', s=2, lw=0)
    ax.scatter(50, 50, s=70, color='aquamarine', label='HI Gas')
    ax.scatter(50, 50, s=70, color='orange', label='HII Gas')
    ax.scatter(50, 50, s=70, color='gray', label='Stars')
    _style_axis(ax, 'Y (kpc)', 'Z (kpc)', xlim=(-20, 20), ylim=(-20, 20))
    ax.legend(loc='lower left', fontsize=14)


def _plot_velocity_dispersion_panel(ax, bin_centers, vlos_dispersion, tsigma, r_half):
    ax.scatter(bin_centers, vlos_dispersion, marker='o', color='black', label='Simulation data', s=8, zorder=3)
    ax.errorbar(
        r_pc / 1000,
        sigma,
        yerr=err_sigma,
        fmt='o',
        color='darkorchid',
        ecolor='gray',
        elinewidth=1,
        label='Walker 2009',
        capsize=4,
        alpha=0.6,
        markersize=4,
        zorder=2,
    )
    ax.hlines(tsigma, 0, 3, lw=2, ls='--', color='gray', zorder=0)
    ax.vlines(r_half, 0, 15, lw=2, ls='--', color='gray', zorder=1)
    ax.scatter(r_half, tsigma, c='red', s=80, zorder=10)
    _style_axis(ax, 'Radius (kpc)', 'Velocity Dispersion (km/s)', xlim=(0, 2.2), ylim=(4, 13.5))
    ax.legend(fontsize=12, loc='upper right')


def _plot_surface_brightness_profile(ax, dprof, mag_obs, mag_obs_err, r_centers, mag_profile):
    ax.errorbar(
        np.radians(dprof['xr']) * d_today,
        mag_obs,
        yerr=mag_obs_err,
        fmt='o',
        capsize=4,
        color='darkorchid',
        ecolor='gray',
        markersize=4,
        elinewidth=1,
        alpha=0.5,
        zorder=1,
        label='Yang 2022',
    )
    ax.scatter(r_centers, mag_profile, label='Simulation data', c='black', s=10, zorder=3)
    _style_axis(ax, 'Radius (kpc)', 'Surface Brightness (mag arcsec$^{-2}$)', xlim=(0, 5), ylim=(34, 22.5))
    ax.legend(fontsize=12, loc='upper right')


def _plot_gas_fraction_panel(ax, dw_elinfo, tsnap, gas_half_ratio, gas_ratio_4rhalf, t_peri):
    gas_half_series = np.asarray(
        dw_elinfo.coldgas_half_mass.to_numpy() / dw_elinfo.star_half_mass.to_numpy(),
        dtype=float,
    )
    gas_full_series = np.asarray(
        dw_elinfo.coldgas_mass.to_numpy() / dw_elinfo.star_mass.to_numpy(),
        dtype=float,
    )
    ax.plot(
        dw_elinfo.age.to_numpy(),
        gas_half_series,
        lw=3,
        c='black',
        label=r'within $R_{\mathrm{half}}$',
    )
    ax.plot(
        dw_elinfo.age.to_numpy(),
        gas_full_series,
        lw=3,
        c='gray',
        label=r'within stellar region',
    )
    ax.scatter(tsnap, gas_half_ratio, c='red', marker='o', s=100, zorder=5)
    ax.scatter(
        tsnap,
        gas_ratio_4rhalf,
        c='salmon',
        marker='o',
        s=100,
        zorder=5,
    )
    ax.vlines(tsnap, 0, 12, color='gray', lw=2, ls='--', zorder=0)
    _style_axis(ax, 'Simulation Time (Gyr)', r'$M_{\mathrm{HI}} / M_{stars}$', xlim=(0, t_peri), ylim=(1e-4, 10.8))
    ax.set_yscale('log')
    ax.legend(loc='lower left', fontsize=15)


def _plot_sigma_history_panel(ax, dw_elinfo, sigma_mw_theoretical, sigma_mw, tsnap, sigma_value, t_peri, sigma_x, sigma_y, sigma_z):
    ax.plot(dw_elinfo.age.to_numpy(), dw_elinfo.sigma.to_numpy(), lw=2, color='black', label=r'$\sigma_{los}$')
    ax.plot(dw_elinfo.age.to_numpy(), dw_elinfo.tsigma.to_numpy(), lw=2, color='gray', label=r'$\sigma_{baryon}$')
    if 'tsigma_xyz' in dw_elinfo.columns:
        ax.plot(dw_elinfo.age.to_numpy(), dw_elinfo.tsigma_xyz.to_numpy(), lw=2, color='orange', label=r'$\sigma_{xyz}$')
    ax.plot(dw_elinfo.age.to_numpy(), sigma_mw_theoretical, lw=2, color='lightcoral', label=r'$\sigma_{MW}$')
    ax.plot(dw_elinfo.age.to_numpy(), sigma_mw, lw=2, color='c', label=r'$\sigma_{est}$')
    ax.scatter(tsnap, sigma_value, s=70, zorder=5, color='red')
    _style_axis(ax, 'Simulation Time (Gyr)', 'velocity dispersion (km/s)', xlim=(0, t_peri * 1.2), ylim=(-0.08, 20.9))
    ax.vlines(tsnap, 0, 25, color='gray', lw=2, ls='--', zorder=0)
    ax.legend(loc='upper left', fontsize=15)
    ax.text(
        0.98,
        0.95,
        (r"$\sigma_x = %.2f$ km/s" % sigma_x) + "\n"
        + (r"$\sigma_y = %.2f$ km/s" % sigma_y) + "\n"
        + (r"$\sigma_z = %.2f$ km/s" % sigma_z),
        transform=ax.transAxes,
        ha='right',
        va='top',
        fontsize=14,
    )


def _compute_plot_snapshot_metrics(snapshot, context, numsp):
    df = snapshot['df']
    dw_cold_gas_mask = snapshot['dw_cold_gas_mask']
    total_dw_star_mask = snapshot['total_dw_star_mask']
    star_coords = snapshot['star_coords']
    rotra_dw_star = snapshot['rotra_dw_star']
    rotdec_dw_star = snapshot['rotdec_dw_star']
    rotra_dw_cold_gas = snapshot['rotra_dw_cold_gas']
    rotdec_dw_cold_gas = snapshot['rotdec_dw_cold_gas']
    d_mean = snapshot['d_mean']
    x_kpc = snapshot['x_kpc']
    y_kpc = snapshot['y_kpc']
    cold_gas_x_kpc = snapshot['cold_gas_x_kpc']
    cold_gas_y_kpc = snapshot['cold_gas_y_kpc']
    dw_elinfo = context['dw_elinfo']
    row = context['elinfo_by_numsp'].loc[numsp]
    star_mass = row['star_mass']
    star_half_mass = row['star_half_mass']
    coldgas_mass = row['coldgas_mass']
    coldgas_half_mass = row['coldgas_half_mass']
    eps = row['eps']
    pa = row['pa']
    r_half = row['rhalf']
    vr = row['vr']
    vtheta = row['vtheta']
    vphi = row['vphi']

    star_df = df.loc[
        total_dw_star_mask,
        ['m', 'x', 'y', 'z', 'vx', 'vy', 'vz'],
    ]
    star_mass_array = star_df['m'].to_numpy()
    x_star = star_df['x'].to_numpy()
    y_star = star_df['y'].to_numpy()
    z_star = star_df['z'].to_numpy()
    vx_star = star_df['vx'].to_numpy()
    vy_star = star_df['vy'].to_numpy()
    vz_star = star_df['vz'].to_numpy()
    cold_gas_df = df.loc[dw_cold_gas_mask, ['y', 'z', 'nh', 'm']]
    hot_gas_df = df.loc[snapshot['dw_hot_gas_mask'], ['y', 'z']]
    cold_gas_y = cold_gas_df['y'].to_numpy()
    cold_gas_z = cold_gas_df['z'].to_numpy()
    hot_gas_y = hot_gas_df['y'].to_numpy()
    hot_gas_z = hot_gas_df['z'].to_numpy()

    gas_ratio_4rhalf = np.nan if star_mass == 0 else coldgas_mass / star_mass
    gas_half_ratio = np.nan if star_half_mass == 0 else coldgas_half_mass / star_half_mass
    gas_frac_4rhalf = np.nan if (coldgas_mass + star_mass) == 0 else coldgas_mass / (coldgas_mass + star_mass)
    gas_half_frac = np.nan if (coldgas_half_mass + star_half_mass) == 0 else coldgas_half_mass / (coldgas_half_mass + star_half_mass)
    r_half_deg = 57.2958 * r_half / d_mean

    if 'cold_gas_center_ra' in row.index and 'cold_gas_center_dec' in row.index:
        cold_gas_center_ra = row['cold_gas_center_ra']
        cold_gas_center_dec = row['cold_gas_center_dec']
    else:
        cold_gas_r = np.sqrt(np.array(rotra_dw_cold_gas) ** 2 + np.array(rotdec_dw_cold_gas) ** 2)
        cold_gas_within_mask = cold_gas_r <= 2.1
        rotra_dw_cold_gas_within = np.array(rotra_dw_cold_gas)[cold_gas_within_mask]
        rotdec_dw_cold_gas_within = np.array(rotdec_dw_cold_gas)[cold_gas_within_mask]
        if len(rotra_dw_cold_gas_within) > 0:
            cold_gas_center_ra, cold_gas_center_dec = Analysis.find_center_2d(
                rotra_dw_cold_gas_within,
                rotdec_dw_cold_gas_within,
                units='offset',
            )
        else:
            cold_gas_center_ra, cold_gas_center_dec = np.nan, np.nan

    if 'pmra' in row.index and 'pmdec' in row.index:
        mean_pmra = row['pmra']
        mean_pmdec = row['pmdec']
    else:
        pos = CartesianRepresentation(
            x_star * u.kpc,
            y_star * u.kpc,
            z_star * u.kpc,
        )
        vel = CartesianDifferential(
            vx_star * u.km / u.s,
            vy_star * u.km / u.s,
            vz_star * u.km / u.s,
        )
        coord = SkyCoord(pos.with_differentials(vel), frame='galactocentric')
        coord_icrs = coord.transform_to('icrs')
        mean_pmra = np.mean(coord_icrs.pm_ra_cosdec).value
        mean_pmdec = np.mean(coord_icrs.pm_dec).value

    rotate = np.array([[np.cos(-pa), -np.sin(-pa)], [np.sin(-pa), np.cos(-pa)]])
    coords = np.vstack((x_kpc, y_kpc))
    rotated_coords = rotate @ coords
    x_rot, y_rot = rotated_coords[0], rotated_coords[1]
    r_centers, mag_profile = Analysis.radial_magnitude_profile(
        x_rot,
        y_rot,
        mass=star_mass_array,
        d_kpc=d_mean,
        ep=eps,
        bins=40,
        m_l_relation=sim_plot_mass_to_light_ratio,
    )
    vlos_array = Analysis.cal_vlos(
        star_coords['xh'],
        star_coords['yh'],
        star_coords['zh'],
        star_coords['vxh'],
        star_coords['vyh'],
        star_coords['vzh'],
    )

    cy = snapshot['cy']
    cz = snapshot['cz']
    cx = snapshot['cx']
    dw_xc = snapshot['dw_xc']
    dw_yc = snapshot['dw_yc']
    dw_zc = snapshot['dw_zc']
    
    if 'sigma_x' in row.index and 'sigma_y' in row.index and 'sigma_z' in row.index:
        sigma_x = row['sigma_x']
        sigma_y = row['sigma_y']
        sigma_z = row['sigma_z']
    else:
        r = np.sqrt((x_star - dw_xc) ** 2 + (y_star - dw_yc) ** 2 + (z_star - dw_zc) ** 2)
        within_500pc = r <= 0.5
        sigma_x = np.nan if not np.any(within_500pc) else np.std(vx_star[within_500pc])
        sigma_y = np.nan if not np.any(within_500pc) else np.std(vy_star[within_500pc])
        sigma_z = np.nan if not np.any(within_500pc) else np.std(vz_star[within_500pc])

    bin_centers, vlos_dispersion = Analysis.get_vlos_dispersion(x_kpc, y_kpc, vlos_array)
    img, extent = Analysis.surface_brightness_map(
        rotra_dw_star,
        rotdec_dw_star,
        star_mass_array,
        d_mean,
        npix=120,
        size_kpc=4,
        mag_sys='vega',
        m_l_relation=sim_plot_mass_to_light_ratio,
    )
    vf, extent_vf = Analysis.get_vlos_field(x_kpc, y_kpc, vlos_array, npix=40)

    vgsr = np.sqrt(vr**2 + vtheta**2 + vphi**2)

    cold_gas_mass_nh = cold_gas_df['nh'].to_numpy() * cold_gas_df['m'].to_numpy()
    cold_gas_mass_contour, x_contour, y_contour, cd_smooth = Analysis.est_gas_contour(
        cold_gas_x_kpc,
        cold_gas_y_kpc,
        cold_gas_mass_nh,
        unit="deg",
        d_mean=d_mean,
    )

    return {
        'row': row,
        'star_mass': star_mass,
        'star_half_mass': star_half_mass,
        'coldgas_mass': coldgas_mass,
        'coldgas_half_mass': coldgas_half_mass,
        'gas_ratio_4rhalf': gas_ratio_4rhalf,
        'gas_half_ratio': gas_half_ratio,
        'gas_frac_4rhalf': gas_frac_4rhalf,
        'gas_half_frac': gas_half_frac,
        'star_y': y_star,
        'star_z': z_star,
        'cold_gas_y': cold_gas_y,
        'cold_gas_z': cold_gas_z,
        'hot_gas_y': hot_gas_y,
        'hot_gas_z': hot_gas_z,
        'cold_gas_center_ra': cold_gas_center_ra,
        'cold_gas_center_dec': cold_gas_center_dec,
        'mean_pmra': mean_pmra,
        'mean_pmdec': mean_pmdec,
        'eps': eps,
        'pa': pa,
        'r_half': r_half,
        'r_half_deg': r_half_deg,
        'r_centers': r_centers,
        'mag_profile': mag_profile,
        'vlos_array': vlos_array,
        'cy': cy,
        'cz': cz,
        'sigma_x': sigma_x,
        'sigma_y': sigma_y,
        'sigma_z': sigma_z,
        'bin_centers': bin_centers,
        'vlos_dispersion': vlos_dispersion,
        'img': img,
        'extent': extent,
        'vf': vf,
        'extent_vf': extent_vf,
        'vr': vr,
        'vtheta': vtheta,
        'vphi': vphi,
        'vgsr': vgsr,
        'cold_gas_mass_contour': cold_gas_mass_contour,
        'x_contour': x_contour,
        'y_contour': y_contour,
        'cd_smooth': cd_smooth,
    }


def _compute_sfr_series(sfh_dw, dw_sfrmass, t_peri, bin_width=0.5):
    if dw_sfrmass is None or len(dw_sfrmass) == 0:
        bins = np.arange(0 - bin_width, t_peri * 1.2, bin_width)
        lookback_obs, sfr_obs = DataProcessor.GetSFR(sfh_dw, bins=bins)
        return np.array([]), np.array([]), lookback_obs, sfr_obs

    filtered_sfrmass = dw_sfrmass[dw_sfrmass['m'] < 10000]
    if len(filtered_sfrmass) == 0:
        bins = np.arange(0 - bin_width, t_peri * 1.2, bin_width)
        lookback_obs, sfr_obs = DataProcessor.GetSFR(sfh_dw, bins=bins)
        return np.array([]), np.array([]), lookback_obs, sfr_obs

    lookback = filtered_sfrmass['age'].to_numpy()
    sfh_mass = filtered_sfrmass['m'].to_numpy()
    bins = np.arange(0 - bin_width, t_peri * 1.2, bin_width)

    mass_sim, edges_sim = np.histogram(lookback, bins=bins, weights=sfh_mass)
    dt = np.diff(edges_sim)
    sfr_sim = mass_sim / dt / 1e4
    lookback_sim = edges_sim[:-1]
    lookback_obs, sfr_obs = DataProcessor.GetSFR(sfh_dw, bins=bins)

    return lookback_sim, sfr_sim, lookback_obs, sfr_obs


def _plot_gas_loss_panel(ax, dw_elinfo, gas_loss_rate, tsnap, t_peri):
    ax.plot(dw_elinfo.age.to_numpy(), gas_loss_rate, lw=2.5, c='black')
    ax.vlines(tsnap, -1e10, 1e10, color='gray', lw=2, ls='--')
    _style_axis(ax, 'Simulation Time (Gyr)', 'Gas Loss Rate (Msun / Gyr)', xlim=(0, t_peri * 1.2), ylim=(0.5e7, -2.5e7))


def _plot_sfr_panel(ax, lookback_sim, sfr_sim, lookback_obs, sfr_obs, t_peri):
    ax.step(lookback_sim, sfr_sim, where='post', label='Simulated SFR', color='black', lw=3, alpha=0.7)
    ax.step(lookback_obs, sfr_obs, where='post', label='Observed SFR', color='orange', lw=3, alpha=0.7)
    _style_axis(ax, 'Lookback Time (Gyr)', r'SFR ($10^{-4} M_{\odot}$ yr$^{-1}$)', xlim=(0, t_peri), ylim=(0, 25))
    ax.legend(loc='upper left')


def _plot_orbit_panel(ax, dw_elinfo, tsnap, current_distance, t_peri, d_mean_gal, vr, vtheta, vphi, vgsr):
    ax.plot(dw_elinfo.age.to_numpy(), dw_elinfo.distance.to_numpy(), color='black', lw=3, zorder=1)
    ax.scatter(
        tsnap,
        current_distance,
        color='red',
        s=80,
        zorder=3,
        label=f'{tsnap:.2f} Gyr',
    )
    ax.hlines(d_today, -0.1, t_peri * 3, color='gray', lw=2, ls='--', zorder=0)
    _style_axis(ax, 'Simulation Time (Gyr)', 'Distance (kpc)', xlim=(0, t_peri * 1.2), ylim=(30, 820))
    ax.legend(loc='lower left', fontsize=16)
    ax.text(
        0.05,
        0.95,
        f'D : {d_mean_gal:.2f} kpc\n'
        f'$v_{{r}}$ : {vr:.2f} km/s\n'
        f'$v_{{\\theta}}$ : {vtheta:.2f} km/s\n'
        f'$v_{{\\phi}}$ : {vphi:.2f} km/s\n'
        f'$v_{{gsr}}$ : {vgsr:.2f} km/s',
        transform=ax.transAxes,
        fontsize=20,
        verticalalignment='top',
        horizontalalignment='left',
    )


def plot(numsp, show_mem=False, context=None, profile=False, profile_memory=False, verbose=False):
    start_time = time.perf_counter()
    start_rss = get_rss_mb() if profile_memory else None
    context = get_plot_context() if context is None else context
    modelname = context['modelname']
    core_radius = context['core_radius']
    dw_elinfo = context['dw_elinfo']
    elinfo_by_numsp = context['elinfo_by_numsp']
    ini_x = context['ini_x']
    ini_y = context['ini_y']
    ini_z = context['ini_z']
    ini_vx = context['ini_vx']
    ini_vy = context['ini_vy']
    ini_vz = context['ini_vz']
    fd_factor_str = context['fd_factor_str']
    sfh_dw = context['sfh_dw']
    dprof = context['dprof']
    mag_obs = context['mag_obs']
    mag_obs_err = context['mag_obs_err']
    gas_loss_rate = context['gas_loss_rate']
    sigma_mw = context['sigma_mw']
    sigma_mw_theoretical = context['sigma_mw_theoretical']
    d_peri = context['d_peri']
    t_peri = context['t_peri']
    dw_sfrmass = context['dw_sfrmass']
    lookback_sim = context['lookback_sim']
    sfr_sim = context['sfr_sim']
    lookback_obs = context['lookback_obs']
    sfr_obs = context['sfr_obs']
    output_folder = context['output_folder']

    if show_mem:
        try:
            import psutil
            process = psutil.Process(os.getpid())
            mem_mb = process.memory_info().rss / 1024 / 1024
            print(f"[numsp={numsp}] Memory usage at start: {mem_mb:.2f} MB")
        except Exception as e:
            print(f"[numsp={numsp}] Memory usage check failed: {e}")

    snapshot = prepare_snapshot_context(
        folder_path=folder_path,
        snapshot_num=numsp,
        core_radius=core_radius,
    )
    after_prepare = time.perf_counter()
    after_prepare_rss = get_rss_mb() if profile_memory else None
    simulation = snapshot['simulation']
    df = snapshot['df']
    tsnap = snapshot['tsnap']
    d_mean_gal = snapshot['d_mean_gal']
    hot_gas_x_kpc = snapshot['hot_gas_x_kpc']
    hot_gas_y_kpc = snapshot['hot_gas_y_kpc']
    cold_gas_x_kpc = snapshot['cold_gas_x_kpc']
    cold_gas_y_kpc = snapshot['cold_gas_y_kpc']
    metrics = _compute_plot_snapshot_metrics(snapshot, context, numsp)
    after_metrics = time.perf_counter()
    after_metrics_rss = get_rss_mb() if profile_memory else None
    row = elinfo_by_numsp.loc[numsp]

    star_mass = metrics['star_mass']
    star_half_mass = metrics['star_half_mass']
    coldgas_mass = metrics['coldgas_mass']
    coldgas_half_mass = metrics['coldgas_half_mass']
    gas_ratio_4Rhalf = metrics['gas_ratio_4rhalf']
    gas_half_ratio = metrics['gas_half_ratio']
    gas_frac_4Rhalf = metrics['gas_frac_4rhalf']
    gas_half_frac = metrics['gas_half_frac']

    sm_str = DataProcessor.sci_notation(star_mass)
    shm_str = DataProcessor.sci_notation(star_half_mass)
    cg_str = DataProcessor.sci_notation(coldgas_mass)
    cghm_str = DataProcessor.sci_notation(coldgas_half_mass)
    cd_threshold_str = DataProcessor.sci_notation(cd_threshold)

    ### --- ###

    fig = plt.figure(figsize=(21, 15), dpi=150)
    gs = gridspec.GridSpec(3, 4)

    # Create axes excluding (2,3) position
    axes = [[None]*4 for _ in range(3)]
    for i in range(3):
        for j in range(4):
            if not (i == 2 and j == 3):  # Skip the (2,3) position
                axes[i][j] = fig.add_subplot(gs[i, j])

    axes = np.array(axes) 

    plt.subplots_adjust(
        left=0.05,   
        right=0.95, 
        top=0.95,   
        bottom=0.08,
        wspace=0.35, 
        hspace=0.22
    )

    #--- Title ---#

    fig.suptitle(f'{modelname}', fontsize=22)

    if verbose:
        print('Begin plotting...')

    #--- Gas sky map (kpc) ---#

    _plot_gas_sky_panel(
        axes[1, 1],
        cold_gas_x_kpc,
        cold_gas_y_kpc,
        hot_gas_x_kpc,
        hot_gas_y_kpc,
    )

    if verbose:
        print('Gas sky map plotted.')

    #--- Stellar sky map (deg) ---#
    _plot_stellar_sky_panel(
        fig,
        axes[0, 0],
        metrics['img'],
        metrics['extent'],
        metrics['cold_gas_center_ra'],
        metrics['cold_gas_center_dec'],
        metrics['x_contour'],
        metrics['y_contour'],
        metrics['cd_smooth'],
        cd_threshold_str,
        metrics['mean_pmra'],
        metrics['mean_pmdec'],
        metrics['r_half_deg'],
        metrics['eps'],
        metrics['pa'],
    )

    if verbose:
        print('Stellar sky map plotted.')

    #--- vlos sky map (deg) ---#
    _plot_vlos_panel(fig, axes[0, 1], metrics['vf'], metrics['extent_vf'])

    if verbose:
        print('vlos sky map plotted.')

    #--- 3D Scene in Y-Z ---#
    _plot_scene_panel(
        axes[0, 3],
        metrics['cold_gas_y'],
        metrics['cold_gas_z'],
        metrics['hot_gas_y'],
        metrics['hot_gas_z'],
        metrics['star_y'],
        metrics['star_z'],
        metrics['cy'],
        metrics['cz'],
    )

    if verbose:
        print('3D scene plotted.')

    #--- velocity dispersion ---#
    _plot_velocity_dispersion_panel(
        axes[1, 0],
        metrics['bin_centers'],
        metrics['vlos_dispersion'],
        row['tsigma'],
        metrics['r_half'],
    )

    if verbose:
        print('Velocity dispersion plotted.')

    #--- Surface luminosity profile ---#
    _plot_surface_brightness_profile(
        axes[2, 0],
        dprof,
        mag_obs,
        mag_obs_err,
        metrics['r_centers'],
        metrics['mag_profile'],
    )

    if verbose:
        print('Surface luminosity profile plotted.')

    #--- Gas-to-stellar mass ratio ---#
    _plot_gas_fraction_panel(
        axes[1, 2],
        dw_elinfo,
        tsnap,
        gas_half_ratio,
        gas_ratio_4Rhalf,
        t_peri,
    )

    if verbose:
        print('Gas-to-stellar mass ratio plotted.')

    #--- Sigma history ---#
    _plot_sigma_history_panel(
        axes[0, 2],
        dw_elinfo,
        sigma_mw_theoretical,
        sigma_mw,
        tsnap,
        row['sigma'],
        t_peri,
        metrics['sigma_x'],
        metrics['sigma_y'],
        metrics['sigma_z'],
    )
    
    if verbose:
        print('Sigma history plotted.')

    #------#

    #--- Central Gas Density ---#

    _plot_gas_loss_panel(axes[2, 2], dw_elinfo, gas_loss_rate, tsnap, t_peri)

    #--- Evolution Histroy ---#

    # axes[2, 2].plot(dw_elinfo.age.to_numpy(), dw_elinfo.coldgas_mass.to_numpy(), lw=2.5, c='aquamarine', label='HI mass within stellar region')
    # axes[2, 2].plot(dw_elinfo.age.to_numpy(), dw_elinfo.coldgas_half_mass.to_numpy(), lw=2.5, c='teal', label='HI mass within $R_{{half}}$')
    # axes[2, 2].plot(dw_elinfo.age.to_numpy(), dw_elinfo.star_mass.to_numpy(), lw=2, c='lightblue', alpha=0.9, label='Stellar mass')
    # axes[2, 2].plot(dw_elinfo.age.to_numpy(), dw_elinfo.star_half_mass.to_numpy(), lw=2, c='darkblue', label='Stellar mass within $R_{{half}}$')

    # axes[2, 2].step(sfh_dw['cosmic_time_shifted'].to_numpy(), 1e9*sfh_dw['cumulative_mass'].to_numpy(), 
    #                 lw=2.5, color='maroon', ls='--', label='SFH in Observation')
    # axes[2, 2].step(sfh_dw['cosmic_time_shifted'].to_numpy(), 1e9*sfh_dw['pure_sfh'].to_numpy(), 
    #                 lw=2.5, color='coral', ls='--', label='Pure SFH in Observation')
    # if dw_sfrmass is not None:
    #     axes[2, 2].step(dw_sfrmass['birth'].to_numpy(), dw_sfrmass['cumulative_mass'].to_numpy(), lw=2, color='indigo', label='SFH in Simulation')

    # axes[2, 2].vlines(tsnap, 0, 1e11, color='gray', lw=2, ls='--')
    # axes[2, 2].hlines(dw_cold_gas_lower_limit, -0.1, T_peri*2, lw=2, ls='--', color='paleturquoise', label='lower limit of HI mass')

    _plot_sfr_panel(axes[2, 1], lookback_sim, sfr_sim, lookback_obs, sfr_obs, t_peri)

    if verbose:
        print('SFR plotted.')

    #--- oribt ---#

    _plot_orbit_panel(
        axes[1, 3],
        dw_elinfo,
        tsnap,
        row['distance'],
        t_peri,
        d_mean_gal,
        metrics['vr'],
        metrics['vtheta'],
        metrics['vphi'],
        metrics['vgsr'],
    )

    #--- Tidal Effect ---#

    # te = axes[2, 1].scatter(np.log10(tidal_eff), np.log10(dw_energy), c=dw_elinfo['age'].to_numpy(), s=10, vmin=0, vmax=max(dw_elinfo['age']), cmap='PuBu')
    # axes[2, 1].scatter(np.log10(tidal_eff_numsp), np.log10(dw_energy_nusmp), c='orangered', s=260, marker='+', lw=3)
    # axes[2, 1].minorticks_on()
    # axes[2, 1].tick_params(axis='both', which='both', direction='in', top=True, right=True, labelsize=10)
    # axes[2, 1].grid(True)
    # axes[2, 1].set_xlim(-33.9, -29.1)
    # axes[2, 1].set_ylim(-33.9, -29.1)
    # axes[2, 1].set_ylabel(r'$log_{10} (\frac{\sigma^2_{los}}{r^2_{half}}) ~ (s^{-2})$', fontsize=xylabel_size)
    # axes[2, 1].set_xlabel(r'$log_{10} (\frac{128}{27} \frac{g^{2}_{MW}}{v^2}) ~ (s^{-2})$', fontsize=xylabel_size)

    # x_tidal = np.linspace(-100, 0, 20)
    # y_tidal = x_tidal

    # axes[2, 1].plot(x_tidal, y_tidal, lw=2, ls='--', c='orchid')

    # divider = make_axes_locatable(axes[2, 1])
    # cax = divider.append_axes("right", size="4%", pad=0.05)
    # cbar = fig.colorbar(te, cax=cax)
    # cbar.set_label(r'Simulation Time (Gyr)', fontsize=12)
    # cax.tick_params(axis='both', which='both', direction='in')
    # cax.minorticks_on()

    #--- Infomation ---#

    info_orbit_text = (
        f"Orbit : {ini_x:.2f}, {ini_y:.2f}, {ini_z:.2f}\n"
        f"        {ini_vx:.2f}, {ini_vy:.2f}, {ini_vz:.2f}\n"
    )

    # info_mass_text = (
    #     f"Star Mass: {sm_str}\n"
    #     f"Star Half-Mass: {shm_str}\n"
    #     f"Cold Gas Mass: {cg_str}\n"
    #     f"Cold Gas Half-Mass: {cghm_str}"
    # )

    fig.text(
        0.935, 0.031,
        info_orbit_text, 
        fontsize=20,
        verticalalignment='bottom',
        horizontalalignment='right'
    )

    gas_frac_contour = metrics['cold_gas_mass_contour'] / (metrics['cold_gas_mass_contour'] + star_mass)

    fig.text(
        0.74, 0.32,               
        # f'{dwarf_name} stellar mass:\n'
        f'$R_{{half}}$: {metrics["r_half"]:.2f} kpc \n'  
        f'$D_{{peri}}$: {d_peri:.2f} kpc \n'
        f'$Stellar Mass_{{4Rhalf}}$: {sm_str} $M_{{\\odot}}$ \n'  
        f'$Stellar Mass_{{Rhalf}}$: {shm_str} $M_{{\\odot}}$ \n'
        f'$Cold Gas Mass_{{4Rhalf}}$: {cg_str} $M_{{\\odot}}$ \n'   
        f'$Cold Gas Mass_{{Rhalf}}$: {cghm_str} $M_{{\\odot}}$ \n'
        f'Gas Fraction in Contour: {gas_frac_contour:.3f} \n'
        f'Gas Fraction in 4$R_{{half}}$: {gas_frac_4Rhalf:.3f} \n'
        f'Gas Fraction in $R_{{half}}$: {gas_half_frac:.3f} \n'
        f'Feedback: {fd_factor_str} median feedback \n',
        fontsize=20,
        ha='left', va='top'
    )

    if verbose:
        print('Information added.')

    output_file = os.path.join(output_folder, f'check_nature_{numsp:03d}.png')
  
    plt.savefig(output_file)
    after_render = time.perf_counter()
    after_render_rss = get_rss_mb() if profile_memory else None
    plt.close(fig)
    
    if verbose:
        print(f"Figure saved to {output_file}")

    df._msg = None
    
    del df
    del simulation
    del fig
    del dw_elinfo, dw_sfrmass, cold_gas_x_kpc, cold_gas_y_kpc, hot_gas_x_kpc, hot_gas_y_kpc
    del metrics
    del info_orbit_text
    del gas_frac_contour, sm_str, shm_str, cg_str, cghm_str, gas_ratio_4Rhalf, gas_half_ratio, gas_frac_4Rhalf, gas_half_frac
    del snapshot

    release_process_memory()
    end_time = time.perf_counter()

    if show_mem:
        try:
            mem_mb = process.memory_info().rss / 1024 / 1024
            print(f"[numsp={numsp}] Memory usage at end: {mem_mb:.2f} MB")
        except Exception as e:
            print(f"[numsp={numsp}] Memory usage check failed: {e}")

    if profile:
        parts = [
            f"pid={os.getpid()}",
            f"numsp={numsp}",
            f"prepare={after_prepare - start_time:.2f}s",
            f"metrics={after_metrics - after_prepare:.2f}s",
            f"render={after_render - after_metrics:.2f}s",
            f"cleanup={end_time - after_render:.2f}s",
            f"total={end_time - start_time:.2f}s",
        ]
        if profile_memory:
            parts.extend([
                f"rss_start={start_rss:.0f}MB",
                f"rss_prepare={after_prepare_rss:.0f}MB",
                f"rss_metrics={after_metrics_rss:.0f}MB",
                f"rss_render={after_render_rss:.0f}MB",
                f"rss_end={get_rss_mb():.0f}MB",
            ])
        print("[PlotFigProfile] " + " ".join(parts), flush=True)

    return {'numsp': numsp, 'status': 'plotted', 'output_file': output_file}

def main():
    global PLOT_CONTEXT
    os.environ.setdefault("DSPH_RUN_ID", str(os.getpid()))
    PLOT_CONTEXT = build_plot_context()
    modelname, dwarf_name, model_num = DataProcessor.parse_model_name()

    print('CubePath: ' + str(cube_path))

    max_snapshot_num = DataProcessor.max_snapshot_number(folder_path)
    if max_snapshot_num is None:
        raise FileNotFoundError(f"No snapshots found under {folder_path}")

    parser = argparse.ArgumentParser(description='Process some integers.')
    default_range = f'0,{max_snapshot_num}'
    
    parser.add_argument('--range', type=str, default=default_range, help='the range of snapshots, e.g., "1,20"')
    parser.add_argument('--processes', type=int, default=1, help='number of processes to use')
    parser.add_argument('--chunksize', type=int, default=1, help='chunksize for pool.imap_unordered')
    parser.add_argument('--dispatch', choices=('blocks', 'dynamic'), default='blocks', help='task dispatch strategy: contiguous snapshot blocks or per-snapshot dynamic scheduling')
    parser.add_argument('--block-size', type=int, default=4, help='number of consecutive snapshots per worker task when --dispatch=blocks')
    parser.add_argument('--maxtasksperchild', type=int, default=4, help='restart each worker after this many pool tasks')
    parser.add_argument('--worker-threads', type=int, default=1, help='limit native BLAS/OpenMP threads inside each worker')
    parser.add_argument('--profile', action='store_true', help='print per-snapshot timing information from each worker')
    parser.add_argument('--profile-memory', action='store_true', help='include per-snapshot RSS information in profile logs')
    parser.add_argument('--no-progress', action='store_true', help='disable tqdm progress bar output')
    parser.add_argument('--verbose-plot', action='store_true', help='print per-panel plotting messages')
    parser.add_argument('--show-mem', action='store_true', help='show memory usage for each snapshot')
    parser.add_argument('--replace', action='store_true', help='replace existing .png files')
    args = parser.parse_args()

    start, end = map(int, args.range.split(','))
    requested_numsp = list(range(start, end + 1))
    output_dir = get_plot_context()['output_folder']
    existing_numsp = [
        numsp for numsp in requested_numsp
        if os.path.exists(os.path.join(output_dir, f'check_nature_{numsp:03d}.png'))
    ]
    if args.replace:
        pending_numsp = requested_numsp
    else:
        existing_set = set(existing_numsp)
        pending_numsp = [numsp for numsp in requested_numsp if numsp not in existing_set]

    print(
        f"PlotFig resume: total={len(requested_numsp)}, "
        f"existing={len(existing_numsp)}, pending={len(pending_numsp)}, replace={args.replace}"
    )

    if not pending_numsp:
        render_video_from_frames(
            output_dir=output_dir,
            dwarf_name=dwarf_name,
            model_num=model_num,
            start_numsp=start,
            frame_count=len(requested_numsp),
        )
        print("PlotFig completed: plotted=0, skipped=0")
        return

    tasks = [
        (
            numsp,
            args.show_mem,
            args.replace,
            args.profile or args.profile_memory,
            args.profile_memory,
            args.verbose_plot,
        )
        for numsp in pending_numsp
    ]

    with get_context("fork").Pool(
        processes=args.processes,
        maxtasksperchild=args.maxtasksperchild,
        initializer=init_worker,
        initargs=(args.worker_threads,),
    ) as pool:
        plotted = 0
        skipped = 0
        progress = ProgressReporter(len(tasks), 'PlotFig', enabled=not args.no_progress, unit='snap', mininterval=0.5)

        try:
            if args.dispatch == 'blocks':
                task_blocks = build_consecutive_blocks(tasks, args.block_size)
                result_iter = pool.imap_unordered(plot_if_needed_block, task_blocks, chunksize=1)
                for block_results in result_iter:
                    for result in block_results:
                        if result['status'] == 'plotted':
                            plotted += 1
                        elif result['status'] == 'skipped':
                            skipped += 1
                    if progress is not None:
                        progress.update(len(block_results))
            else:
                result_iter = pool.imap_unordered(plot_if_needed_task, tasks, chunksize=args.chunksize)
                for result in result_iter:
                    if result['status'] == 'plotted':
                        plotted += 1
                    elif result['status'] == 'skipped':
                        skipped += 1
                    if progress is not None:
                        progress.update(1)
        finally:
            progress.close()

    render_video_from_frames(
        output_dir=output_dir,
        dwarf_name=dwarf_name,
        model_num=model_num,
        start_numsp=start,
        frame_count=len(requested_numsp),
    )
    print(f"PlotFig completed: plotted={plotted}, skipped={skipped}")


def plot_if_needed(numsp, show_mem, replace, profile=False, profile_memory=False, verbose=False):
    output_folder = get_plot_context()['output_folder']
    output_file = os.path.join(output_folder, f'check_nature_{numsp:03d}.png')
    if (not replace) and os.path.exists(output_file):
        return {'numsp': numsp, 'status': 'skipped', 'output_file': output_file}
    return safe_plot(
        numsp,
        show_mem=show_mem,
        profile=profile,
        profile_memory=profile_memory,
        verbose=verbose,
    )


def plot_if_needed_task(task):
    return plot_if_needed(*task)


def plot_if_needed_block(task_block):
    return [plot_if_needed_task(task) for task in task_block]

if __name__ == "__main__":
    main() 
