import pandas as pd
from multiprocessing import get_context
import argparse
import ctypes
import os
import resource
import time
from basefunc import DataProcessor, GalaxySimulation
from snapshot_context import prepare_snapshot_context
from snapshot_metrics import compute_snapshot_summary
from variable import core_radius_dict, folder_path, gizmo_config, orbit_file
from pathlib import Path
import sys
import csv
import gc

try:
    from tqdm.auto import tqdm
except ImportError:
    tqdm = None

ELINFO_COLUMNS = [
    'star_mass', 'star_half_mass',
    'hotgas_mass', 'hotgas_half_mass',
    'coldgas_mass', 'coldgas_half_mass',
    'mw_mass_r', 'eps', 'pa', 'gas_density',
    'vr', 'vtheta', 'vphi', 'distance_gal', 'rhalf',
    'distance', 'age', 'sigma', 'tsigma',
    'tsigma_xyz',
    'sigma_x', 'sigma_y', 'sigma_z',
    'pmra', 'pmdec', 'cold_gas_center_ra', 'cold_gas_center_dec',
    'numsp',
]

try:
    LIBC = ctypes.CDLL("libc.so.6")
except OSError:
    LIBC = None

try:
    from threadpoolctl import threadpool_limits
except ImportError:
    threadpool_limits = None

THREADPOOL_CONTROLLER = None


def build_consecutive_blocks(items, block_size):
    if block_size <= 0:
        raise ValueError("block_size must be positive")
    return [items[i:i + block_size] for i in range(0, len(items), block_size)]


class ProgressReporter:
    def __init__(self, total, desc, enabled=True, unit='snap', mininterval=0.5):
        self.total = total
        self.desc = desc
        self.enabled = enabled and total > 0
        self.unit = unit
        self.mininterval = mininterval
        self.count = 0
        self._last_print = 0.0
        self._use_tqdm = self.enabled and tqdm is not None and sys.stdout.isatty()
        self._progress = None
        if self._use_tqdm:
            self._progress = tqdm(
                total=total,
                desc=desc,
                unit=unit,
                dynamic_ncols=True,
                mininterval=mininterval,
                file=sys.stdout,
            )
        elif self.enabled:
            print(f"[{self.desc}Progress] 0/{self.total} {self.unit}", flush=True)

    def update(self, n=1):
        if not self.enabled:
            return
        self.count += n
        if self._progress is not None:
            self._progress.update(n)
            return

        now = time.perf_counter()
        if self.count >= self.total or now - self._last_print >= self.mininterval:
            print(f"[{self.desc}Progress] {self.count}/{self.total} {self.unit}", flush=True)
            self._last_print = now

    def close(self):
        if self._progress is not None:
            self._progress.close()


def release_process_memory():
    gc.collect()
    if LIBC is not None:
        try:
            LIBC.malloc_trim(0)
        except Exception:
            pass


def get_rss_mb():
    try:
        with open("/proc/self/statm", "r") as fh:
            rss_pages = int(fh.readline().split()[1])
        page_size = os.sysconf("SC_PAGE_SIZE")
        return rss_pages * page_size / (1024.0 * 1024.0)
    except Exception:
        return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0


def init_worker(worker_threads):
    global THREADPOOL_CONTROLLER
    if threadpool_limits is not None and worker_threads is not None and worker_threads > 0:
        THREADPOOL_CONTROLLER = threadpool_limits(limits=worker_threads)


class GetInfo:

    def __init__(self):
        self.modelname, self.dwarf_name, self.num = DataProcessor.parse_model_name()
        
        # Set up file paths using Path objects
        self.inifile = DataProcessor.resolve_dwarf_ini_path(self.dwarf_name)
        print(f"[GetInfo] Using initial INI file: {self.inifile}")
        
        # Get dwarf parameters
        self.dw_particles = GalaxySimulation.get_dw_num(self.inifile)
        if self.dw_particles <= 0:
            raise ValueError(f"Invalid number of dwarf particles: {self.dw_particles}")
            
        self.core_radius = core_radius_dict.get(self.dwarf_name)
        if self.core_radius is None:
            raise ValueError(f"Core radius not found for dwarf: {self.dwarf_name}")
            
        # Set output file path
        self.output_csv_file = Path(f'./elinfo_{self.modelname}.csv')
        self.profile = False
        self.profile_memory = False
        self.float_precision = 8
        self.show_progress = True

    def get_info(self, numsp):
        start_time = time.perf_counter()
        start_rss = get_rss_mb() if self.profile_memory else None
        snapshot = prepare_snapshot_context(
            folder_path=folder_path,
            snapshot_num=numsp,
            core_radius=self.core_radius,
            include_mw_gas=True,
            mw_gas_radius=300.0,
            include_dark_matter=True,
        )
        after_prepare = time.perf_counter()
        after_prepare_rss = get_rss_mb() if self.profile_memory else None

        simulation = snapshot['simulation']
        df = snapshot['df']
        summary = compute_snapshot_summary(snapshot, numsp)
        after_summary = time.perf_counter()
        after_summary_rss = get_rss_mb() if self.profile_memory else None
        simulation.df = None
        del snapshot
        del df, simulation
        release_process_memory()
        end_time = time.perf_counter()

        if self.profile:
            parts = [
                f"pid={os.getpid()}",
                f"numsp={numsp}",
                f"prepare={after_prepare - start_time:.2f}s",
                f"summary={after_summary - after_prepare:.2f}s",
                f"cleanup={end_time - after_summary:.2f}s",
                f"total={end_time - start_time:.2f}s",
            ]
            if self.profile_memory:
                parts.extend([
                    f"rss_start={start_rss:.0f}MB",
                    f"rss_prepare={after_prepare_rss:.0f}MB",
                    f"rss_summary={after_summary_rss:.0f}MB",
                    f"rss_end={get_rss_mb():.0f}MB",
                ])
            print("[GetInfoProfile] " + " ".join(parts), flush=True)
        
        return [summary['star_mass'], summary['star_half_mass'], 
                summary['hotgas_mass'], summary['hotgas_half_mass'], 
                summary['coldgas_mass'], summary['coldgas_half_mass'], 
                summary['mw_mass_r'], summary['eps'], summary['pa'], summary['gas_density'],
                summary['vr'], summary['vtheta'], summary['vphi'], summary['distance_gal'], summary['rhalf'], 
                summary['distance'], summary['age'], summary['sigma'], summary['tsigma'],
                summary['tsigma_xyz'],
                summary['sigma_x'], summary['sigma_y'], summary['sigma_z'],
                summary['pmra'], summary['pmdec'], summary['cold_gas_center_ra'], summary['cold_gas_center_dec'],
                summary['numsp']]

    def get_info_block(self, numsp_block):
        return [self.get_info(numsp) for numsp in numsp_block]

    def process_and_stream(self, pool, numsp_list, write_header=False, chunksize=1, dispatch='blocks', block_size=4):
        total = len(numsp_list)
        progress = ProgressReporter(total, 'GetInfo', enabled=self.show_progress, unit='snap', mininterval=0.5)

        with open(self.output_csv_file, 'a', newline='', buffering=16384) as csvfile:
            writer = csv.writer(csvfile)
            if write_header:
                writer.writerow(ELINFO_COLUMNS)

            try:
                if dispatch == 'blocks':
                    blocks = build_consecutive_blocks(numsp_list, block_size)
                    result_iter = pool.imap_unordered(self.get_info_block, blocks, chunksize=1)
                    for block_results in result_iter:
                        for result in block_results:
                            writer.writerow(DataProcessor.format_row_for_csv(result, float_precision=self.float_precision))
                            del result
                        if progress is not None:
                            progress.update(len(block_results))
                        del block_results
                        release_process_memory()
                else:
                    result_iter = pool.imap_unordered(self.get_info, numsp_list, chunksize=chunksize)
                    for result in result_iter:
                        writer.writerow(DataProcessor.format_row_for_csv(result, float_precision=self.float_precision))
                        if progress is not None:
                            progress.update(1)
                        del result
                        release_process_memory()
            finally:
                progress.close()

    def main(self):
        os.environ.setdefault("DSPH_RUN_ID", str(os.getpid()))
        orbit_data = DataProcessor.read_orbit_parameters(orbit_file)
        if orbit_data is None:
            print("Failed to read orbit data.")
            sys.exit(1)

        fd_value = DataProcessor.read_feedback_value(gizmo_config)
        if fd_value is None:
            print("Failed to extract timescale value.")
            sys.exit(1)

        max_snapshot_num = DataProcessor.max_snapshot_number(folder_path)
        if max_snapshot_num is None:
            print(f"No snapshots found under {folder_path}")
            sys.exit(1)

        parser = argparse.ArgumentParser(description='Process some integers.')
        default_range = f'0,{max_snapshot_num}'
        parser.add_argument('--range', type=str, default=default_range, 
                            help='the range of snapshots, e.g., "1,20"')
        parser.add_argument('--processes', type=int, default=1, 
                            help='number of processes to use')
        parser.add_argument('--chunksize', type=int, default=1,
                            help='chunksize for pool.imap_unordered')
        parser.add_argument('--dispatch', choices=('blocks', 'dynamic'), default='blocks',
                            help='task dispatch strategy: contiguous snapshot blocks or per-snapshot dynamic scheduling')
        parser.add_argument('--block-size', type=int, default=4,
                            help='number of consecutive snapshots per worker task when --dispatch=blocks')
        parser.add_argument('--maxtasksperchild', type=int, default=4,
                            help='restart each worker after this many pool tasks to reduce memory growth')
        parser.add_argument('--worker-threads', type=int, default=1,
                            help='limit native BLAS/OpenMP threads inside each worker')
        parser.add_argument('--profile', action='store_true',
                            help='print per-snapshot timing information from each worker')
        parser.add_argument('--profile-memory', action='store_true',
                            help='include per-snapshot RSS information in profile logs')
        parser.add_argument('--float-precision', type=int, default=8,
                            help='significant digits for floating-point values written to csv')
        parser.add_argument('--no-progress', action='store_true',
                            help='disable tqdm progress bar output')
        args = parser.parse_args()
        self.profile = args.profile or args.profile_memory
        self.profile_memory = args.profile_memory
        self.float_precision = args.float_precision
        self.show_progress = not args.no_progress

        start, end = map(int, args.range.split(','))
        requested_numsp = list(range(start, end + 1))
        numsp_list = list(requested_numsp)

        # 断点续写：读取已完成的numsp
        finished_numsp = set()
        if self.output_csv_file.exists():
            try:
                df_exist = DataProcessor.read_csv_with_comments(self.output_csv_file, dtype=DataProcessor.ELINFO_DTYPE_MAP)
                missing_columns = [column for column in ELINFO_COLUMNS if column not in df_exist.columns]
                if missing_columns:
                    print(
                        "Existing elinfo file is missing new summary columns: "
                        + ", ".join(missing_columns)
                    )
                    print("Please rebuild elinfo from scratch before resuming with the refactored GetInfo.py.")
                    sys.exit(1)
                if 'numsp' in df_exist.columns:
                    finished_numsp = set(df_exist['numsp'].astype(int).tolist())
            except Exception as e:
                print(f"Warning: Failed to read existing csv: {e}")

        # 只处理未完成的快照
        numsp_list = [n for n in numsp_list if n not in finished_numsp]
        completed_in_range = len(requested_numsp) - len(numsp_list)
        print(
            f"GetInfo resume: total={len(requested_numsp)}, "
            f"completed={completed_in_range}, pending={len(numsp_list)}"
        )

        # 如果文件不存在则写注释和表头，否则追加
        write_header = False
        if not self.output_csv_file.exists():
            with open(self.output_csv_file, 'w') as f:
                f.write(f"# Orbit Data: {','.join(map(str, orbit_data))}\n")
                f.write(f"# Timescale_fd: {fd_value}\n")
            write_header = True

        if numsp_list:
            with get_context("fork").Pool(
                processes=args.processes,
                maxtasksperchild=args.maxtasksperchild,
                initializer=init_worker,
                initargs=(args.worker_threads,),
            ) as pool:
                self.process_and_stream(
                    pool,
                    numsp_list,
                    write_header=write_header,
                    chunksize=args.chunksize,
                    dispatch=args.dispatch,
                    block_size=args.block_size,
                )
            print(f"\nData saved to {self.output_csv_file}")
        else:
            print("All snapshots in the specified range have already been processed.")

        self.sort_csv_by_numsp()

    def sort_csv_by_numsp(self):
        df = DataProcessor.read_csv_with_comments(self.output_csv_file, dtype=DataProcessor.ELINFO_DTYPE_MAP)
        df_sorted = df.sort_values(by='numsp', ascending=True)
   
        with open(self.output_csv_file, 'r') as f:
            lines = f.readlines()
        comments = [line for line in lines if line.startswith('#')]
  
        with open(self.output_csv_file, 'w') as f:
            for line in comments:
                f.write(line)
            df_sorted.to_csv(f, index=False)

if __name__ == "__main__":
    processor = GetInfo()
    processor.main()
