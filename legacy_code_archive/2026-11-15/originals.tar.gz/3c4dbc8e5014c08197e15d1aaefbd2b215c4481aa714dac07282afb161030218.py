import numpy as np
import pandas as pd
import os
from multiprocessing import get_context
import argparse
from basefunc import DataProcessor, GalaxySimulation, Analysis, CoordinateTransform
from variable import *
from pathlib import Path
import sys
import csv
import re
import gc
from photutils.isophote import Ellipse, EllipseGeometry

class GetInfo:

    def __init__(self):
        # Get model name from current directory
        self.modelname = Path().resolve().name
        match = re.match(r'([A-Za-z]+)(\d+)', self.modelname)
        if not match:
            raise ValueError(f"Invalid model name format: '{self.modelname}'. "
                           f"Expected format: <dwarf_name><number>")

        # Extract dwarf name and number
        self.dwarf_name, num_str = match.groups()
        self.num = int(num_str)
        
        # Set up file paths using Path objects
        self.inifile = Path(f'./{self.dwarf_name}.ini')
        if not self.inifile.exists():
            raise FileNotFoundError(f"INI file not found: {self.inifile}")
        
        # Get dwarf parameters
        self.dw_particles = GalaxySimulation.get_dw_num(self.inifile)
        if self.dw_particles <= 0:
            raise ValueError(f"Invalid number of dwarf particles: {self.dw_particles}")
            
        self.core_radius = core_radius_dict.get(self.dwarf_name)
        if self.core_radius is None:
            raise ValueError(f"Core radius not found for dwarf: {self.dwarf_name}")
            
        # Set output file path
        self.output_csv_file = Path(f'./elinfo_{self.modelname}.csv')

    def get_info(self, numsp):

        simulation = GalaxySimulation(folder_path=folder_path, snapshot_num=numsp)
        df, tsnap = simulation.load_snapshot()
        df = simulation.center_on_MW()

        mw_star_mask, dw_star_mask = simulation.classify_mw_dwarf(df=df, r_exclude=5, dwarf_radius=3*self.core_radius, k_density=16)

        # try:
        #     # Only attempt centering if we have MW particles
        #     if mw_mask.any():
        #         df = simulation.center_on_MW(mw_mask, iterations=2, radius=100)
        #     else:
        #         print(f"Warning: No MW particles found in snapshot {numsp}, skipping centering")
        # except Exception as e:
        #     print(f"Warning: Failed to center on MW in snapshot {numsp}: {str(e)}")

        df = simulation.convert_coordinates(df=df)

        dw_gas_mask = simulation.find_dwarf_gas(dw_star_mask=dw_star_mask)
        mw_gas_mask = simulation.find_MW_gas(radius=300)
        # new_star_mask = df.tp == 4
        dw_hot_gas_mask = dw_gas_mask & (df.temp >= 20000)
        dw_cold_gas_mask = dw_gas_mask & (df.temp < 20000)
        # new_dw_star_mask, new_mw_star_mask = simulation.classify_new_dwarf_stars(dw_star_mask)
        # total_dw_star_mask = dw_star_mask | new_dw_star_mask
        # total_mw_star_mask = mw_star_mask | new_mw_star_mask
        total_dw_star_mask = dw_star_mask
        total_mw_star_mask = mw_star_mask
        
        dw_cra, dw_cdec = Analysis.find_center(df[total_dw_star_mask].ra, df[total_dw_star_mask].dec)
        dw_xc, dw_yc = Analysis.find_center(df[total_dw_star_mask].x, df[total_dw_star_mask].y, units='kpc')
        dw_yc, dw_zc = Analysis.find_center(df[total_dw_star_mask].y, df[total_dw_star_mask].z, units='kpc')
        rotra_all, rotdec_all = Analysis.rotate_to_sky(df.ra, df.dec, center=[dw_cra, dw_cdec])

        d_mean = np.mean(df[total_dw_star_mask].rh)
        d_mean_gal = np.mean(df[total_dw_star_mask].r)

        mw_star_r = total_mw_star_mask & (df['r'] <= d_mean_gal)
        mw_gas_r = mw_gas_mask & (df['r'] <= d_mean_gal)
        mass_mw_star_r = np.sum(df.loc[mw_star_r, 'm'])
        mass_mw_gas_r = np.sum(df.loc[mw_gas_r, 'm'])

        mw_mass_r = mass_mw_star_r + mass_mw_gas_r

        rotra_dw_star, rotdec_dw_star = rotra_all[total_dw_star_mask], rotdec_all[total_dw_star_mask]
        rotra_dw_hot_gas, rotdec_dw_hot_gas = rotra_all[dw_hot_gas_mask], rotdec_all[dw_hot_gas_mask]
        rotra_dw_cold_gas, rotdec_dw_cold_gas = rotra_all[dw_cold_gas_mask], rotdec_all[dw_cold_gas_mask]

        x_kpc = np.asarray(np.radians(rotra_dw_star) * d_mean)
        y_kpc = np.asarray(np.radians(rotdec_dw_star) * d_mean)
        hot_gas_x_kpc = np.asarray(np.radians(rotra_dw_hot_gas) * d_mean)
        hot_gas_y_kpc = np.asarray(np.radians(rotdec_dw_hot_gas) * d_mean)
        cold_gas_x_kpc = np.asarray(np.radians(rotra_dw_cold_gas) * d_mean)
        cold_gas_y_kpc = np.asarray(np.radians(rotdec_dw_cold_gas) * d_mean)

        #--- Get total mass in dwarf galaxy for different components ---#

        # star_points = np.column_stack([x_kpc, y_kpc])
        # cold_points = np.column_stack([cold_gas_x_kpc, cold_gas_y_kpc])
        # hot_points = np.column_stack([hot_gas_x_kpc, hot_gas_y_kpc])

        # boundary_path = Analysis.estimate_galaxy_boundary(x_kpc, y_kpc)

        # star_in = boundary_path.contains_points(star_points)
        # cold_in = boundary_path.contains_points(cold_points)
        # hot_in = boundary_path.contains_points(hot_points)

        # M_star = df.loc[total_dw_star_mask, 'm'][star_in].sum()
        # M_cold_gas = df.loc[dw_cold_gas_mask, 'm'][cold_in].sum()
        # M_hot_gas = df.loc[dw_hot_gas_mask, 'm'][hot_in].sum()

        #--- Wolf-comparison quantities ---#
        # R_e_kpc is the 2D projected stellar half-light radius on the sky.
        # r_half_3d_kpc = 4/3 * R_e_kpc is the deprojected 3D half-light radius
        # used for the Wolf enclosed-mass comparison.
        # sigma_global is the mass-weighted LOS dispersion of all stellar particles.
        # sigma_re is the mass-weighted LOS dispersion of stars with projected
        # radius <= R_e_kpc.
        # sigma_wolf is the Wolf-estimator prediction based on M_rhalf inside
        # r_half_3d_kpc, including only the baryonic components that actually
        # exist in this simulation (stars + hot gas + cold gas, no dark matter).

        eps, pa = Analysis.calculate_ellipticity(x_kpc, y_kpc, mass=df[total_dw_star_mask].m.values, n_neighbors=30)

        Rotate = np.array([[np.cos(-pa), -np.sin(-pa)],
                   [np.sin(-pa),  np.cos(-pa)]])
        coords = np.vstack((x_kpc, y_kpc))  # shape: (2, N)
        rotated_coords = Rotate @ coords        # shape: (2, N)

        x_rot, y_rot = rotated_coords[0], rotated_coords[1]
        R_e_kpc = Analysis.half_light_radius(x_rot, y_rot, df[total_dw_star_mask].m, ep=eps)
        r_half_3d_kpc = (4.0 / 3.0) * R_e_kpc

        # image = Analysis.particles_to_image(x_kpc, y_kpc, df[total_dw_star_mask].m)

        # geometry = EllipseGeometry(x_kpc, y_kpc, sma=10, eps=0.3, pa=0.0)
        # ellipse = Ellipse(image, geometry)
        # isolist = ellipse.fit_image()

        # r_half = isolist.get_half_light_radius()
        # eps = isolist.eps
        # pa = isolist.pa

        # dw_star_rhalf_mask = Analysis.get_radial_mask(x_kpc, y_kpc, r_half)
        # dw_hot_gas_rhalf_mask = Analysis.get_radial_mask(hot_gas_x_kpc, hot_gas_y_kpc, r_half)
        # dw_cold_gas_rhalf_mask = Analysis.get_radial_mask(cold_gas_x_kpc, cold_gas_y_kpc, r_half)

        dw_star_rhalf_mask = Analysis.get_3d_radial_mask(df[total_dw_star_mask].x - dw_xc, df[total_dw_star_mask].y - dw_yc, 
                                                         df[total_dw_star_mask].z - dw_zc, r_half_3d_kpc)
        dw_hot_gas_rhalf_mask = Analysis.get_3d_radial_mask(df[dw_hot_gas_mask].x - dw_xc, df[dw_hot_gas_mask].y - dw_yc, 
                                                           df[dw_hot_gas_mask].z - dw_zc, r_half_3d_kpc)
        dw_cold_gas_rhalf_mask = Analysis.get_3d_radial_mask(df[dw_cold_gas_mask].x - dw_xc, df[dw_cold_gas_mask].y - dw_yc, 
                                                            df[dw_cold_gas_mask].z - dw_zc, r_half_3d_kpc)

        M_star_rhalf = df.loc[total_dw_star_mask, :].loc[dw_star_rhalf_mask, 'm'].sum()
        M_hot_gas_rhalf = df.loc[dw_hot_gas_mask, :].loc[dw_hot_gas_rhalf_mask, 'm'].sum()
        M_cold_gas_rhalf = df.loc[dw_cold_gas_mask, :].loc[dw_cold_gas_rhalf_mask, 'm'].sum()
        M_rhalf = M_star_rhalf + M_hot_gas_rhalf + M_cold_gas_rhalf

        vlos_array = Analysis.cal_vlos(df[total_dw_star_mask].xh, df[total_dw_star_mask].yh, df[total_dw_star_mask].zh,
                                   df[total_dw_star_mask].vxh, df[total_dw_star_mask].vyh, df[total_dw_star_mask].vzh)
        star_mass_array = df.loc[total_dw_star_mask, 'm'].to_numpy()
        projected_radius_kpc = np.sqrt(x_kpc**2 + y_kpc**2)

        vlos_mean_global, sigma_global = Analysis.mass_weighted_mean_and_dispersion(vlos_array, star_mass_array)
        R_e_mask = projected_radius_kpc <= R_e_kpc
        vlos_mean_re, sigma_re = Analysis.mass_weighted_mean_and_dispersion(vlos_array[R_e_mask], star_mass_array[R_e_mask])

        dw_star_4rhalf_mask = Analysis.get_radial_mask(x_kpc, y_kpc, 4 * R_e_kpc)
        dw_hot_gas_4rhalf_mask = Analysis.get_radial_mask(hot_gas_x_kpc, hot_gas_y_kpc, 4 * R_e_kpc)
        dw_cold_gas_4rhalf_mask = Analysis.get_radial_mask(cold_gas_x_kpc, cold_gas_y_kpc, 4 * R_e_kpc)

        v_r, v_theta, v_phi = Analysis.cartesian_to_spherical(
            df.loc[total_dw_star_mask, 'x'][dw_star_4rhalf_mask].to_numpy(), df.loc[total_dw_star_mask, 'y'][dw_star_4rhalf_mask].to_numpy(), 
            df.loc[total_dw_star_mask, 'z'][dw_star_4rhalf_mask].to_numpy(), 
            df.loc[total_dw_star_mask, 'vx'][dw_star_4rhalf_mask].to_numpy(), df.loc[total_dw_star_mask, 'vy'][dw_star_4rhalf_mask].to_numpy(), 
            df.loc[total_dw_star_mask, 'vz'][dw_star_4rhalf_mask].to_numpy()
            )
        
        mean_vr, mean_vtheta, mean_vphi = np.mean(v_r), np.mean(v_theta), np.mean(v_phi)
        sigma_wolf = np.sqrt(M_rhalf / (930.0 * R_e_kpc * 1000.0))

        M_star = df.loc[total_dw_star_mask, :].loc[dw_star_4rhalf_mask, 'm'].sum()
        M_cold_gas = df.loc[dw_cold_gas_mask, :].loc[dw_cold_gas_4rhalf_mask, 'm'].sum()
        M_hot_gas = df.loc[dw_hot_gas_mask, :].loc[dw_hot_gas_4rhalf_mask, 'm'].sum()

        gas_density = Analysis.GetGasdensity(cold_gas_x_kpc, cold_gas_y_kpc, df.loc[dw_cold_gas_mask].m, R_e_kpc)

        masses = {
            'star': M_star,
            'star_half': M_star_rhalf,
            'hotgas': M_hot_gas,
            'hotgas_half': M_hot_gas_rhalf,
            'coldgas': M_cold_gas,
            'coldgas_half': M_cold_gas_rhalf,
            'mw_mass_r': mw_mass_r
        }

        # del star_points, cold_points, hot_points, boundary_path
        # del star_in, cold_in, hot_in
        del x_kpc, y_kpc, hot_gas_x_kpc, hot_gas_y_kpc, cold_gas_x_kpc, cold_gas_y_kpc
        del rotra_all, rotdec_all, rotra_dw_star, rotdec_dw_star
        del rotra_dw_hot_gas, rotdec_dw_hot_gas, rotra_dw_cold_gas, rotdec_dw_cold_gas
        del dw_cra, dw_cdec
        del mass_mw_star_r, mass_mw_gas_r, mw_mass_r
        # del ellipticity, pa, Rotate, coords, rotated_coords, x_rot, y_rot
        # del pa, eps
        del dw_star_rhalf_mask, dw_hot_gas_rhalf_mask, dw_cold_gas_rhalf_mask
        del M_star, M_cold_gas, M_hot_gas, M_star_rhalf, M_hot_gas_rhalf, M_cold_gas_rhalf
        del M_rhalf, star_mass_array, projected_radius_kpc, R_e_mask, vlos_array
        del vlos_mean_global, vlos_mean_re
        df._mgr = None
        del df, simulation

        gc.collect()
        
        return [masses['star'], masses['star_half'], 
                masses['hotgas'], masses['hotgas_half'], 
                masses['coldgas'], masses['coldgas_half'], 
                masses['mw_mass_r'], eps, pa, gas_density,
                mean_vr, mean_vtheta, mean_vphi, d_mean_gal, R_e_kpc, 
                d_mean, tsnap, sigma_global, sigma_re, sigma_wolf, 
                numsp]

    def process_and_stream(self, pool, numsp_list, write_header=False):
        columns = ['star_mass', 'star_half_mass', 
                   'hotgas_mass', 'hotgas_half_mass', 
                   'coldgas_mass', 'coldgas_half_mass', 
                   'mw_mass_r', 'eps', 'pa', 'gas_density',
                   'vr', 'vtheta', 'vphi', 'distance_gal', 'rhalf', 
                   'distance', 'age', 'sigma', 'sigma_re', 'tsigma', 'numsp']

        with open(self.output_csv_file, 'a', newline='', buffering=16384) as csvfile:
            writer = csv.writer(csvfile)
            if write_header:
                writer.writerow(columns)
            for result in pool.imap_unordered(self.get_info, numsp_list):
                writer.writerow(result)

                del result
                gc.collect()

    def main(self):
        orbit_data = DataProcessor.read_orbit_parameters(orbit_file)
        if orbit_data is None:
            print("Failed to read orbit data.")
            sys.exit(1)

        fd_value = DataProcessor.read_feedback_value(gizmo_config)
        if fd_value is None:
            print("Failed to extract timescale value.")
            sys.exit(1)

        snapshot_files = [f for f in os.listdir(folder_path) if f.startswith('snapshot')]
        max_snapshot_num = len(snapshot_files) - 1

        parser = argparse.ArgumentParser(description='Process some integers.')
        default_range = f'0,{max_snapshot_num}'
        parser.add_argument('--range', type=str, default=default_range, 
                            help='the range of snapshots, e.g., "1,20"')
        parser.add_argument('--processes', type=int, default=1, 
                            help='number of processes to use')
        args = parser.parse_args()

        start, end = map(int, args.range.split(','))
        numsp_list = list(range(start, end + 1))

        # 断点续写：读取已完成的numsp
        finished_numsp = set()
        if self.output_csv_file.exists():
            try:
                df_exist = pd.read_csv(self.output_csv_file, comment='#')
                if 'numsp' in df_exist.columns:
                    finished_numsp = set(df_exist['numsp'].astype(int).tolist())
            except Exception as e:
                print(f"Warning: Failed to read existing csv: {e}")

        # 只处理未完成的快照
        numsp_list = [n for n in numsp_list if n not in finished_numsp]

        # 如果文件不存在则写注释和表头，否则追加
        write_header = False
        if not self.output_csv_file.exists():
            with open(self.output_csv_file, 'w') as f:
                f.write(f"# Orbit Data: {','.join(map(str, orbit_data))}\n")
                f.write(f"# Timescale_fd: {fd_value}\n")
            write_header = True

        if numsp_list:
            with get_context("fork").Pool(processes=args.processes) as pool:
                self.process_and_stream(pool, numsp_list, write_header=write_header)
            print(f"\nData saved to {self.output_csv_file}")
        else:
            print("All snapshots in the specified range have already been processed.")

        self.sort_csv_by_numsp()

    def sort_csv_by_numsp(self):

        # import pandas as pd
        df = pd.read_csv(self.output_csv_file, comment='#')
        df_sorted = df.sort_values(by='numsp', ascending=True)
   
        with open(self.output_csv_file, 'r') as f:
            lines = f.readlines()
        comments = [line for line in lines if line.startswith('#')]
  
        with open(self.output_csv_file, 'w') as f:
            for line in comments:
                f.write(line)
            df_sorted.to_csv(f, index=False)

if __name__ == "__main__":
    processor = GetInfo()
    processor.main()
